import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { Workbook, SpreadsheetFile } from '@oai/artifact-tool';

const outputDir = path.dirname(fileURLToPath(import.meta.url));
const load = async (name) => JSON.parse(await fs.readFile(path.join(outputDir, name), 'utf8'));
const [instancesRaw, attempts, aggregate] = await Promise.all([
  load('instances.json'), load('attempts.json'), load('aggregate.json'),
]);
if (instancesRaw.length !== 300 || attempts.length !== 326) throw new Error('Unexpected source populations');
const rank = {error: 0, empty_patch: 1, unresolved: 2, resolved: 3};
const instances = [...instancesRaw].sort((a,b) => rank[a.status]-rank[b.status] || a.instance_id.localeCompare(b.instance_id));
const byId = new Map();
for (const a of attempts) {
  if (!byId.has(a.instance_id)) byId.set(a.instance_id, []);
  byId.get(a.instance_id).push(a);
}
for (const list of byId.values()) list.sort((a,b) => a.attempt.localeCompare(b.attempt));
const textOf = (value) => {
  if (value == null) return '';
  if (typeof value === 'string') return value;
  if (Array.isArray(value)) return value.map(textOf).filter(Boolean).join('\n');
  return JSON.stringify(value);
};
const firstNonempty = (...values) => values.find(v => v != null && textOf(v).trim()) ?? '';
const goldLabel = (x) => x.gold_resolved === true ? '通过' : x.gold_resolved === false ? '未通过' : '无记录';
const reasonText = (x) => firstNonempty(x.agent_reason, x.state_reason, x.execution_reason);
const fallbackSummary = (x) => {
  if (x.thinking_only_4096_end && x.status === 'empty_patch') return '末轮仅有 thinking，输出为 4096 tokens，随后标记 completed；疑似截断被视为完成。';
  if (x.status === 'resolved') return '官方 tracked F2P / P2P 全部通过。';
  if (x.gold_resolved === false) return '参考补丁未通过本次环境验证，Agent 未启动。';
  if (x.status === 'unresolved') return `官方 tracked 测试失败：F2P ${x.f2p_failure ?? 0}，P2P ${x.p2p_failure ?? 0}。`;
  return textOf(reasonText(x));
};
const fallbackAction = (x) => {
  if (x.status === 'resolved') return '';
  if (x.gold_resolved === false) return '先排查依赖、外部服务和 gold 测试稳定性，再决定是否启用 Agent。';
  if (x.thinking_only_4096_end) return '保留 stop_reason；核查 max_tokens / thinking-only 响应处理，再复测。';
  if (textOf(reasonText(x)).includes('incomplete chunked read')) return '稳定 API 连接，支持响应中断恢复，单独记录基础设施失败。';
  if (x.agent_status === 'limit') return '回看最后若干轮的重复工具调用与验证反馈，定位循环或错误停止。';
  if (x.status === 'unresolved') return '按失败测试和断言定位补丁缺口；区分目标未修复与回归。';
  return '结合运行日志与事件序列定位未产生补丁的原因。';
};

const workbook = Workbook.create();
const overview = workbook.worksheets.add('总览');
const detail = workbook.worksheets.add('逐题300');
const history = workbook.worksheets.add('历史尝试326');
const palette = {ink:'#17273F', dark:'#243E60', blue:'#346CA3', pale:'#EDF3F9', red:'#A52C38', amber:'#FFF0CC', lightRed:'#FCE8E7', gray:'#6B7280'};
const font = 'Arial';
for (const sheet of [overview,detail,history]) sheet.showGridLines = false;
overview.tabColor = palette.dark;

function colName(n) { let s=''; for (;n>0;n=Math.floor((n-1)/26)) s=String.fromCharCode(65+(n-1)%26)+s; return s; }
function styleBase(sheet, range) {
  sheet.getRange(range).format = {font:{name:font,size:10,color:palette.ink},verticalAlignment:'center',rowHeight:23};
}
function title(sheet, text, lastCol) {
  sheet.getRange('A2').values=[[text]];
  sheet.getRange('A2').format.font={name:font,size:15,bold:true,color:palette.ink};
  sheet.getRange(`A3:${lastCol}3`).format.borders={bottom:{style:'thin',color:'#9AAEC5'}};
  sheet.getRange('A2').format.rowHeight=29;
}
function header(sheet, range) {
  sheet.getRange(range).format={fill:palette.dark,font:{name:font,size:10,bold:true,color:'#FFFFFF'},horizontalAlignment:'center',verticalAlignment:'center',rowHeight:29,wrapText:true};
}
function makeTable(sheet, headers, rows, name, widths) {
  const last=colName(headers.length), end=rows.length+5;
  styleBase(sheet,`A1:${last}${end}`);
  sheet.getRange(`A5:${last}${end}`).values=[headers,...rows];
  const table=sheet.tables.add(`A5:${last}${end}`,true,name);
  table.style='TableStyleLight1';
  table.showFilterButton=true;
  header(sheet,`A5:${last}5`);
  for(let i=0;i<widths.length;i++) sheet.getRange(`${colName(i+1)}1:${colName(i+1)}${end}`).format.columnWidth=widths[i];
  sheet.freezePanes.freezeRows(5);
  sheet.freezePanes.freezeColumns(2);
  return end;
}

const detailHeaders=['题目 ID','仓库','官方结果','归因分类','分析摘要','建议措施','gold 验证','Agent 状态','attempt 数','模型 attempt 数','首次流水线结果','F2P 成功','F2P 失败','P2P 成功','P2P 失败','最新 tokens','累计 tokens','最新请求','累计请求','主模型轮数','推理秒数','修改文件','官方失败测试','证据路径','末轮内容类型','末轮输出 tokens','疑似 thinking 截断'];
const detailRows=instances.map(x=>{
  const a=x.analysis||{};
  const summary=firstNonempty(a.summary,a.finding,a.reason,a.explanation,typeof a==='string'?a:null,fallbackSummary(x));
  const action=firstNonempty(a.recommendation,a.action,a.next_action,a.next_step,a.suggestion,fallbackAction(x));
  const evidence=firstNonempty(a.evidence,x.evidence,`${x.attempt_path}/state.json`);
  return [x.instance_id,x.repo,x.status,x.category,textOf(summary),textOf(action),goldLabel(x),x.agent_status??'未启动',x.attempt_count,x.model_attempt_count,x.first_status,x.f2p_success,x.f2p_failure,x.p2p_success,x.p2p_failure,x.latest_total_tokens,x.cumulative_tokens,x.latest_request_attempts,x.cumulative_requests,x.lead_turns,x.agent_elapsed_seconds,textOf(x.patch_files),textOf(x.failed_tests),textOf(evidence),textOf(x.last_assistant_types),x.last_response_output_tokens,x.thinking_only_4096_end?1:0];
});
const detailEnd=makeTable(detail,detailHeaders,detailRows,'InstanceResults',[40,29,17,35,79,72,15,17,13,16,20,13,13,13,13,18,18,14,14,15,15,77,90,115,28,20,23]);
title(detail,'SWE-bench Lite 逐题分析','AA');
detail.getRange('A3').values=[['最新 attempt。可筛选未通过题目。F2P / P2P 为官方 tracked 测试分组；疑似截断不等于已确认 API stop_reason。']];
detail.getRange(`E6:F${detailEnd}`).format.wrapText=true;
detail.getRange(`E6:F${detailEnd}`).format.verticalAlignment='top';
detail.getRange(`V6:X${detailEnd}`).format.wrapText=true;
detail.getRange(`I6:T${detailEnd}`).format.numberFormat='#,##0';
detail.getRange(`U6:U${detailEnd}`).format.numberFormat='0.0';
detail.getRange(`Z6:AA${detailEnd}`).format.numberFormat='#,##0';
const units=s=>[...textOf(s)].reduce((sum,c)=>sum+(c.codePointAt(0)>255?2:1),0);
const lineCount=(s,width)=>textOf(s).split('\n').reduce((sum,line)=>sum+Math.max(1,Math.ceil(units(line)/width)),0);
detailRows.forEach((row,i)=>{
  const lines=Math.max(lineCount(row[4],77),lineCount(row[5],70),lineCount(row[21],75),lineCount(row[22],88),lineCount(row[23],113));
  detail.getRange(`A${i+6}:AA${i+6}`).format.rowHeight=Math.max(30,lines*14+9);
});
detail.getRange(`C6:C${detailEnd}`).conditionalFormats.addCustom('C6<>"resolved"',{fill:palette.amber,font:{color:palette.red}});
detail.getRange(`M6:M${detailEnd}`).conditionalFormats.add('cellIs',{operator:'greaterThan',formula:0,format:{fill:palette.lightRed,font:{color:palette.red}}});
detail.getRange(`O6:O${detailEnd}`).conditionalFormats.add('cellIs',{operator:'greaterThan',formula:0,format:{fill:palette.lightRed,font:{color:palette.red}}});

const historyHeaders=['题目 ID','仓库','attempt','流水线结果','最后阶段','Agent 状态','首次流水线','首次 Agent 启动','有模型请求','gold 验证','补丁状态','官方判分状态','请求数','tokens','推理秒数','异常或停止原因','state 证据路径','最新 attempt'];
const historyRows=attempts.map(x=>{
  const list=byId.get(x.instance_id);
  const firstAgent=list.find(a=>a.agent_status!=null);
  return [x.instance_id,x.repo,x.attempt,x.status,x.phase,x.agent_status??'未启动',list[0]===x?1:0,firstAgent===x?1:0,(x.latest_request_attempts??0)>0?1:0,goldLabel(x),x.patch_status,x.evaluation_status,x.latest_request_attempts??0,x.latest_total_tokens??0,x.agent_elapsed_seconds,textOf(reasonText(x)),`${x.attempt_path}/state.json`,list.at(-1)===x?1:0];
});
const historyEnd=makeTable(history,historyHeaders,historyRows,'AttemptHistory',[40,29,18,18,17,18,18,21,18,15,19,21,16,19,16,100,120,18]);
title(history,'SWE-bench Lite 历史尝试','R');
history.getRange('A3').values=[['每行一个流水线 attempt。首次流水线、首次 Agent 启动、有模型请求三列均用 1 / 0 标记；启动异常可能没有模型请求。']];
history.getRange(`G6:I${historyEnd}`).format.numberFormat='0';
history.getRange(`M6:N${historyEnd}`).format.numberFormat='#,##0';
history.getRange(`O6:O${historyEnd}`).format.numberFormat='0.0';
history.getRange(`P6:Q${historyEnd}`).format.wrapText=true;
history.getRange(`A6:R${historyEnd}`).format.rowHeight=44;
history.getRange(`D6:D${historyEnd}`).conditionalFormats.addCustom('D6="error"',{fill:palette.lightRed,font:{color:palette.red}});

styleBase(overview,'A1:H66');
for(const [col,width] of [['A',43],['B',19],['C',19],['D',4],['E',23],['F',19],['G',19],['H',19]]) overview.getRange(`${col}1:${col}66`).format.columnWidth=width;
title(overview,'Aki-Code SWE-bench Lite 评测分析','H');
overview.getRange('A3').values=[['300 题，deepseek-flash，2026-10-20 归档分析']];
overview.getRange('A5:C5').values=[['指标','数量 / 用量','比率']];
header(overview,'A5:C5');
overview.getRange('A6:A14').values=[['完整选择集'],['最新 attempt 通过'],['gold 验证通过'],['gold 通过子集的解题率'],['非空补丁已判分'],['首次流水线通过'],['有历史重试的题目'],['累计模型请求'],['累计 tokens（含缓存）']];
const dEnd=detailEnd, hEnd=historyEnd;
overview.getRange('B6:B14').formulas=[
  [`=COUNTA('逐题300'!$A$6:$A$${dEnd})`],
  [`=COUNTIFS('逐题300'!$C$6:$C$${dEnd},"resolved")`],
  [`=COUNTIFS('逐题300'!$G$6:$G$${dEnd},"通过")`],
  ['=B7'],
  [`=COUNTIFS('逐题300'!$C$6:$C$${dEnd},"resolved")+COUNTIFS('逐题300'!$C$6:$C$${dEnd},"unresolved")`],
  [`=COUNTIFS('逐题300'!$K$6:$K$${dEnd},"resolved")`],
  [`=COUNTIFS('逐题300'!$I$6:$I$${dEnd},">1")`],
  [`=SUM('历史尝试326'!$M$6:$M$${hEnd})`],
  [`=SUM('历史尝试326'!$N$6:$N$${hEnd})`],
];
overview.getRange('C7:C12').formulas=[['=B7/B6'],['=B8/B6'],['=B9/B8'],['=B10/B6'],['=B11/B6'],['=B12/B6']];
overview.getRange('B6:B14').format.numberFormat='#,##0';
overview.getRange('C6:C14').format.numberFormat='0.00%';
overview.getRange('A7:C7').format.fill=palette.pale;
overview.getRange('A7:C7').format.font.bold=true;

overview.getRange('E5:F5').values=[['最新官方结果','题目数']];
header(overview,'E5:F5');
const statuses=['resolved','empty_patch','unresolved','error'];
const statusLabels=['已解决','空补丁','非空但未解决','gold 验证失败'];
overview.getRange('E6:E9').values=statusLabels.map(v=>[v]);
overview.getRange('F6:F9').formulas=statuses.map(s=>[`=COUNTIFS('逐题300'!$C$6:$C$${dEnd},"${s}")`]);

const categories=[...new Set(instances.map(x=>x.category))].sort((a,b)=>{
  if(a==='已解决')return -1;if(b==='已解决')return 1;
  return instances.filter(x=>x.category===b).length-instances.filter(x=>x.category===a).length;
});
overview.getRange('A17:C17').values=[['归因分类','题目数','占完整选择集']];header(overview,'A17:C17');
overview.getRange(`A18:A${17+categories.length}`).values=categories.map(c=>[c]);
overview.getRange(`B18:B${17+categories.length}`).formulas=categories.map((c,i)=>[`=COUNTIFS('逐题300'!$D$6:$D$${dEnd},A${18+i})`]);
overview.getRange(`C18:C${17+categories.length}`).formulas=categories.map((c,i)=>[`=B${18+i}/$B$6`]);
overview.getRange(`C18:C${17+categories.length}`).format.numberFormat='0.0%';
const noteLines=[
  '主成绩采用最新 attempt，包含基础设施重试。',
  '剔除 gold 失败的比率仅用于诊断。',
  '首次流水线通过率不等同模型 pass@1。',
  '首次 Agent 已知 213 解，2 份旧补丁待判。',
  '44 份空补丁没有送官方测试执行。',
  'tokens 含缓存输入，不等于供应商费用。',
];
overview.getRange('E12').values=[['口径说明']];overview.getRange('E12').format.font.bold=true;
noteLines.forEach((s,i)=>overview.getRange(`E${13+i}`).values=[[s]]);
overview.getRange('E13:E18').format.font.color=palette.gray;
overview.getRange('E13:E18').format.font.italic=true;

const repoStart=39;const repos=[...new Set(instances.map(x=>x.repo))].sort();
overview.getRange('A39:H39').values=[['仓库','题目数','gold 通过','已解决','全量通过率','gold 子集通过率','累计 tokens','累计请求']];
header(overview,'A39:H39');
overview.getRange('D1:D66').format.columnWidth=17;
overview.getRange('E39:H52').format.columnWidth=20;
for(let i=0;i<repos.length;i++){
  const r=repoStart+i+1;overview.getRange(`A${r}`).values=[[repos[i]]];
  overview.getRange(`B${r}:H${r}`).formulas=[[
    `=COUNTIFS('逐题300'!$B$6:$B$${dEnd},A${r})`,
    `=COUNTIFS('逐题300'!$B$6:$B$${dEnd},A${r},'逐题300'!$G$6:$G$${dEnd},"通过")`,
    `=COUNTIFS('逐题300'!$B$6:$B$${dEnd},A${r},'逐题300'!$C$6:$C$${dEnd},"resolved")`,
    `=D${r}/B${r}`,`=IF(C${r}=0,"n.a.",D${r}/C${r})`,
    `=SUMIFS('逐题300'!$Q$6:$Q$${dEnd},'逐题300'!$B$6:$B$${dEnd},A${r})`,
    `=SUMIFS('逐题300'!$S$6:$S$${dEnd},'逐题300'!$B$6:$B$${dEnd},A${r})`,
  ]];
}
overview.getRange('E40:F51').format.numberFormat='0.0%';
overview.getRange('G40:H51').format.numberFormat='#,##0';
overview.getRange('A54').values=[['数据来源与复核']];overview.getRange('A54').format.font.bold=true;
const sources=[
  '原始记录：task_output-wsl/lite-baseline-001；逐题与历史表的证据列保留定位路径。',
  '本工作簿读取同目录 instances.json、attempts.json；汇总由公式从两张明细表计算。',
  '已复核：官方报告与 state 判分一致，patch hash 一致，driver / source / dataset SHA 匹配 manifest。',
  'Gold 失败不直接证明题目有错；详细根因与边界见 report.md 和 harness_notes.md。',
  'Django-14155 有 1 条 F2P 解析漏记；另有真实 F2P 失败，整题未解决不变。',
];
sources.forEach((s,i)=>overview.getRange(`A${55+i}`).values=[[s]]);
overview.getRange('A55:A59').format.font.color=palette.gray;

// Verify that source edits change the formula-backed headline, and restore the record.
const resolvedRow=instances.findIndex(x=>x.status==='resolved')+6;
detail.getRange(`C${resolvedRow}`).values=[['unresolved']];
workbook.recalculate();
if(overview.getRange('B7').values[0][0]!==213) throw new Error('Recalculation response failed');
detail.getRange(`C${resolvedRow}`).values=[['resolved']];
// Final recalculation, then verify against independent source controls.
workbook.recalculate();
const metricValues=overview.getRange('B6:C14').values;
const independent={selected:instances.length,resolved:instances.filter(x=>x.status==='resolved').length,gold:instances.filter(x=>x.gold_resolved===true).length,calls:attempts.reduce((s,x)=>s+(x.latest_request_attempts??0),0),tokens:attempts.reduce((s,x)=>s+(x.latest_total_tokens??0),0)};
const computed={selected:metricValues[0][0],resolved:metricValues[1][0],gold:metricValues[2][0],calls:metricValues[7][0],tokens:metricValues[8][0]};
for(const k of Object.keys(independent))if(computed[k]!==independent[k])throw new Error(`Metric mismatch ${k}: ${computed[k]} / ${independent[k]}`);
const checks=[];
for(const [sheet,range] of [['总览','A5:C14'],['总览','A39:H43'],['逐题300','A5:H9'],['历史尝试326','A5:I9']]){
  const inspected=await workbook.inspect({kind:'table',range:`'${sheet}'!${range}`,include:'values,formulas',tableMaxRows:10,tableMaxCols:9,maxChars:7000});checks.push(inspected.ndjson);
}
const errors=await workbook.inspect({kind:'match',searchTerm:'#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A|#NUM!|#NULL!|#SPILL!|#CALC!',options:{useRegex:true,maxResults:100},summary:'Final formula error scan',maxChars:5000});
checks.push(errors.ndjson);
await fs.writeFile(path.join(outputDir,'workbook_checks.txt'),checks.join('\n\n'),'utf8');
for(const [sheetName,range,name] of [['总览','A1:H28','preview_overview.png'],['总览','A38:H52','preview_repos.png'],['逐题300','A1:D13','preview_instances.png'],['历史尝试326','A1:I13','preview_attempts.png']]){
  const preview=await workbook.render({sheetName,range,scale:1.3,format:'png'});
  await fs.writeFile(path.join(outputDir,name),new Uint8Array(await preview.arrayBuffer()));
}
const output=await SpreadsheetFile.exportXlsx(workbook);
await output.save(path.join(outputDir,'analysis.xlsx'));
await fs.writeFile(path.join(outputDir,'workbook_validation.json'),JSON.stringify({independent,computed,sourceCounts:{instances:instances.length,attempts:attempts.length},sheets:['总览','逐题300','历史尝试326'],createdAt:new Date().toISOString()},null,2));
console.log(JSON.stringify({output:path.join(outputDir,'analysis.xlsx'),independent,computed}));
