# Gold 与基础设施审查

检查全部300题的最新attempt和26个历史attempt，未运行模型或重跑评测。证据路径以仓库根目录为基准，逐题证据及1-based行号见gold_infra_findings.json。

- 最新gold通过295题、失败5题；五题的FAIL_TO_PASS均全通过，仅PASS_TO_PASS失败，且两次attempt失败目标集合相同。不能称为“gold算法答案错误”。五题未启动agent，既不能算模型失败，也不能计成功。
- matplotlib-23913：test_warn_big_data_best_loc期待UserWarning，实际DID NOT WARN，重试复现；疑运行性能/警告条件敏感，但没有证据确定阈值。
- requests-2317、2674、3362：test_connect_timeout与test_total_timeout_connect依赖10.255.255.1造成连接超时，实际能连接或ReadTimeout；重试复现。环境网络行为与测试假设不符。
- requests-863：test_connection_keepalive_and_close收到Connection: close而期待keep-alive，重试复现，属于HTTP服务/网络行为假设失效。
- 最新6题API incomplete chunked read，其中matplotlib-25079部分补丁仍resolved；其余5题空补丁。不是6题全部失分。
- Astropy-6938/7746明确runner拒绝子模块工作区，启动后约5.9秒失败，无result.json；属于工程接入/兼容性缺陷，应与API及模型解题失败分开。
- Sympy-20590达到1200秒超时但回收补丁resolved，不是超时失分。
- 历史26个额外attempt：5个同样gold断言失败、1个Docker Hub manifest EOF、14个image阶段连接重置但无明细日志、5个harness远程requirements获取失败、1个Docker镜像inspect返回404。14个image阶段连接重置不能仅凭阶段名归为Docker故障；按当前脚本顺序推测test_spec前置网络失败。后续attempt已恢复基础设施执行，其中17题resolved、1题unresolved、3题empty_patch，五gold仍失败。
- 原始pytest全套输出与官方目标集合判定不同：例如Flask-4045 gold全套116 failed/11 errors但gold.resolved=true，Xarray-4094全套4 failed却resolved，Xarray-4493 gold43 failed而grading44 failed。应对比指定FAIL_TO_PASS/PASS_TO_PASS以及gold-agent差异，不能按原始failed总数判归因。pytest项目自身的嵌套测试会有预期失败输出，不能把关键字ERROR扫描直接当环境故障。

建议：保留214/300作为本批全流程结果；单列214/295（仅排除gold未验证题），API/runner影响另报，不能把排除问题后的比例叫标准SWE-bench成绩。网络与计时类gold问题先修复或隔离外部假设后重新验证，再重跑受影响agent；API应针对流中断保留可恢复会话并重试。runner子模块支持需要独立修复。

补充系统扫描：24题gold原始套件末尾汇总有failed/errors，其中19题官方目标集合仍通过；全部24题已纳入secondary_environment_findings并保留末尾汇总行号。另有部分unittest风格输出不带pytest末尾汇总，24是此可识别口径的计数，不能解释为全部环境故障总量。多数为依赖版本/弃用警告、外部服务假设或原始测试兼容性问题；具体原因不确定的已标明。
