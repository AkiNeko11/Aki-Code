"""Produce a Chinese narrative and a self-contained, offline analysis viewer."""
from __future__ import annotations

import collections
import html
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]


def load(name):
    return json.loads((OUT / name).read_text(encoding="utf-8"))


def cell(text):
    return str(text or "").replace("|", "／").replace("\n", " ")


def link(path, label=None):
    # Raw logs are intentionally local-only. Keep identifiers portable on GitHub.
    return f"`{label or Path(path).name}`"


def reason(row):
    a = row.get("analysis", {})
    return a.get("reason") or a.get("summary") or row["agent_reason"] or row["category"]


def action(row):
    a = row.get("analysis", {})
    return a.get("next_action") or a.get("recommendation") or a.get("action") or ""


def main():
    rows, agg = load("instances.json"), load("aggregate.json")
    assert len(rows) == 300 and sum(r["status"] == "resolved" for r in rows) == 214
    assert all(r.get("analysis") for r in rows if r["status"] != "resolved"), "Wait for reviewer findings before publishing."
    notes = load("agent_findings.json")
    categories = collections.Counter(r["category"] for r in rows)
    failed = [r for r in rows if r["status"] != "resolved"]
    # This narrative distinguishes observed records from diagnosis and future proposals.
    report = """# Aki-Code SWE-bench Lite 300 题评测分析

分析日期：2026-10-20。运行：`lite-baseline-001`，run_id `559f352a5911`。模型为 `deepseek-flash`，官方 harness 版本 4.1.0，2 个 worker。此次只读取测试脚本及保存的日志、补丁和官方报告，没有重新调用模型、运行 Docker、修改 Agent 或覆盖原始结果。

## 先看结论

**当前最新 attempt 的完整成绩为 214/300 = 71.33%。86 道未通过里，能直接确认是 gold/外部网络/接入兼容性阻断的有 12 道；另有 17 道呈现非常一致的单次输出截断迹象。** 因此，直接把 86 道统称为模型解题失败会误导改进方向。

| 最新结果与失败机制 | 题数 | 占全部300题 | 判断依据 |
| --- | ---: | ---: | --- |
| 官方通过 | 214 | 71.33% | 官方 report.resolved=true |
| 有补丁但未通过官方目标测试集合 | 37 | 12.33% | 31题仅F2P失败、3题仅P2P失败、3题两类均失败 |
| 达到60轮上限，最终无补丁 | 20 | 6.67% | limit + 空diff |
| 疑似thinking输出截断，最终无补丁 | 17 | 5.67% | completed，但末轮只有thinking，输出增量恰好4096 |
| 模型API流式连接中断，最终无补丁 | 5 | 1.67% | incomplete chunked read，无工作区改动 |
| Gold验证失败，Agent未启动 | 5 | 1.67% | gold的F2P全部通过，P2P失败，重试复现 |
| Runner不支持子模块工作区 | 2 | 0.67% | 控制台明确抛出Submodule workspaces are not supported |
| 合计 | 300 | 100.00% | 互斥分类，每题只计一次 |

`F2P` 是问题需要修复的 FAIL_TO_PASS 测试，`P2P` 是要求保持通过的 PASS_TO_PASS 回归测试。表内“输出截断”是强证据诊断，日志没有保存原始 stop_reason，因此没有将其写成已经证实的服务端截断原因。

## 成绩口径：保留全量成绩，单列诊断子集

| 口径 | 分子／分母 | 比例 | 用途 |
| --- | ---: | ---: | --- |
| 最新attempt，全量300题 | 214／300 | 71.33% | 本次全流程观测成绩 |
| 仅gold在本环境通过的题 | 214／295 | 72.54% | 排除无法有效评测的5题，辅助判断 |
| 再排除5道API中断失分及2道子模块接入失败 | 214／288 | 74.31% | 条件子集诊断，具有选择偏差，不替代全量成绩 |
| 仅最终提交非空补丁的题 | 214／251 | 85.26% | 补丁提交后的通过比例，不能当成总体成功率 |

不把排除的题自动补成成功。17道疑似截断和20道达到轮数上限的题也没有被加分。是否能修复并通过，需要修正后独立重跑，不能由现有记录推算。

## 最需要优先处理的异常：thinking-only 被当作 completed

236道Agent状态为completed的题中，有21道最后一次assistant消息只有thinking，没有text或tool_use；这21道末次响应的output_tokens增量全部为4096，与manifest中的单次 `MAX_TOKENS=4096` 一致。其中17道为空补丁、3道有补丁但不通过、1道已通过（sympy-19007）。

例如sympy-22005只执行4轮，最后一轮消耗4096输出token，随后记录completed，工作区仍为空补丁。这与60轮总预算耗尽不同。不能把completed作为“模型完整结束解题”的可靠信号，也不能只靠“加大每题总token预算”修复这一类问题。

建议在后续实现中保留原始stop_reason、响应块类型、单次输出增量；当响应只有thinking或明确被截断时，应进入可恢复的继续执行／异常状态，并受总调用、时间、token预算约束。先用这17题做针对性复测，再比较完整批次。这里提出的是工程验证方向，本次没有读取或修改Agent实现。

17道空补丁题：

{thinking_ids}

3道已有补丁但也出现该末轮异常的题：matplotlib-22711、sphinx-8506、sympy-12171。它们同时存在官方测试失败，不能把全部失败责任都归给响应截断。

## Gold失败：是本次测试条件不成立，不能直接说参考补丁写错

以下5题每题保存了两次gold验证，失败测试集合均复现。它们的F2P全部成功，失败都发生在P2P。Agent被gold gate阻止，没有开始推理。

| 题目 | 原始日志现象 | 可支持的归因 |
| --- | --- | --- |
| matplotlib-23913 | test_warn_big_data_best_loc期待UserWarning，实际DID NOT WARN | 警告触发条件／运行表现敏感，具体阈值机制尚未证实 |
| requests-2317 | 对10.255.255.1的连接应ConnectTimeout，实际未按预期超时或为ReadTimeout | 网络环境与测试假设不符 |
| requests-2674 | 同类connect/total-connect-timeout测试失败 | 网络环境与测试假设不符 |
| requests-3362 | 同类连接超时测试失败，另有目标集合外fixture噪声 | 网络假设失效，并伴有历史测试依赖兼容问题 |
| requests-863 | 服务返回Connection: close，测试期待keep-alive | 外部HTTP服务／连接行为与测试假设不符 |

详细测试名、完整证据路径与行号见 [gold专项核查](gold_infra_notes.md) 和 `gold_infra_findings.json`。不要将gold验证通过等同于原始pytest全部测试通过：例如Flask-4045的gold原始输出有116 failed/11 errors，但官方跟踪的目标集合仍全部通过；Xarray-4094的gold和Agent日志都有4个失败，官方结果仍是通过。这些基线噪声不能算Agent新引入的缺陷。按可识别的外层测试套件末尾汇总，共24题的gold原始输出含failed/errors，其中19题官方目标集合仍通过。此统计避免将pytest项目嵌套子测试的预期失败计入，不应解释为24道环境阻断题。

## API与运行接入问题

最新attempt出现明确API流式断连的共有6题，其中5题失分：astropy-14182、django-11742、django-11848、django-16910、matplotlib-25332。matplotlib-25079虽然同样断连，已收集到的补丁仍通过，所以API事件数是6，实际失分数是5。

astropy-6938、astropy-7746的控制台均明确报 `ValueError: Submodule workspaces are not supported by this runner yet.`。这是运行接入兼容性缺陷，不应归为模型API问题或模型不会解题。

当前脚本的 `--retry-errors` 只重试流水线error/interrupted。上述API中断如果最终产生empty_patch，就不会被它自动选中。因此仅重试error并不能补齐API受损样本。建议未来根据独立的失败原因选择恢复路径：有可校验补丁先重试判分，未生成补丁且明确传输失败再恢复Agent；所有历史尝试继续保留。

## 轮数、权限拒绝与真正的补丁失败

50题触发的全部是60轮主模型上限，没有观察到这些题是80次调用上限或100万token上限停止。其中21题通过、9题有补丁但未通过、20题没有补丁。达到上限不等于补丁错误，但20道始终未落地修改的题值得重点观察“定位／探测消耗过长”的行为。它们消耗14,771,996 tokens，约占最新attempt总token的14.89%。

latest日志共有255次权限拒绝，分布在153题。92道最终通过的题也出现过拒绝，所以拒绝次数只能作为排查信号，不能独立判定主因。常见拒绝围绕git元数据、越界临时目录和runner管理的输出路径。可将允许写入目录、测试临时文件位置与runner职责更清楚地暴露给Agent，减少重复试探；不需要先放宽所有权限。

37道已判分未通过的题中，官方记录40个F2P failure和11个P2P failure。这是测试项数量，不能当成题数。Django-14155有一条F2P实际打印ok，但和前一个测试粘在同一日志行，被官方parser漏掉。该题另外两条F2P仍有真实断言失败，整题仍为unresolved；没有因此调整成绩。其余已核查失败有真实失败输出。

目标测试已通过、仅回归失败的3题是django-13660、pylint-7114、sphinx-10451。这些题应优先检查修复的泛化边界，不能只继续优化问题描述中的单个示例。具体到每道题的失败测试、停止状态、日志解释与下一步建议，见后面的86题清单和可筛选总表。

下面几例说明，不能把原始日志中的其他兼容报错当作排除Agent责任的充分证据：

| 题目 | 官方目标失败的具体原因 | 对改进的启示 |
| --- | --- | --- |
| django-12700 | 递归脱敏把tuple统一变成list，嵌套容器类型不符 | 修复值的同时保持返回类型契约 |
| django-13660 | 目标2项通过，但exec使用空字典导致原有globals行为失效 | 复现新问题后也验证旧调用上下文 |
| matplotlib-22835 | BoundaryNorm不再崩溃，数值输出仍为[-1.]而非[-1.0] | 格式和精度是外部行为的一部分 |
| scikit-learn-10949 | 警告已出现，但消息的was converted与were all converted不符 | 与gold对照可区分真实目标失败和pytest兼容噪声 |
| sympy-13043 | issue允许多个解决方向，Agent选排序list，测试要求set | 结合既有API契约决定返回容器，避免只满足叙述中的一种解释 |

## 重试记录与pass@1

本目录有326个attempt，26题各有两次。第一次流水线通过197题（65.67%），之后最新结果为214题。26个历史attempt里，24个没有模型请求，多为镜像、前置网络或gold阻断；不能把17题恢复通过都说成模型多次采样收益。

仅django-11564、matplotlib-18869实际各运行过两次Agent。它们第一次都留下非空补丁，官方判分却没有生成report，之后整个流水线重跑。按每题第一次Agent启动统计，现有证据确定213题通过，2份旧补丁结果未知。因此严格的该口径尚不能补齐；全量确定通过数为213，若这两份旧补丁都通过则为215。**213至215只是两份缺失判分造成的结果区间，不是统计置信区间。**

现有grade命令只处理最新attempt，不能直接找回这两份旧补丁。建议将旧patch及其原配置复制到独立恢复运行中单独判分；原结果目录保留。本次没有执行该恢复。

## 项目分布

| 项目 | 题数 | 官方通过 | 空补丁 | 补丁未过 | Gold阻断 | 全量通过率 |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
{repo_table}

SymPy有16道补丁未过、13道空补丁，是最多的未解决来源（29题）。Django未解决24题，其中18道为空补丁，比其6道补丁未过更突出。scikit-learn为21/23，SymPy为48/77；不同项目难度和样本数不同，这里是描述性比较，不代表能力因果结论。Requests原始1/6主要被4道gold阻断拉低，不能据此判断Agent对Requests尤其弱。

## 用量与耗时

全部attempt累计9,247次请求、9,235次有返回usage的调用、99,620,472 tokens。构成为28,285,519非缓存输入、67,506,944缓存读取输入、3,828,009输出；包含缓存token，不能直接乘统一价格推算费用。缺少响应的请求也可能有供应商计费，精确费用需供应商账单。

仅最新attempt为9,208次请求、99,219,675 tokens。重试被替换的两份模型答案额外消耗39次请求、400,797 tokens，已正确计入summary。没有把重试成本丢掉。

Agent elapsed累计28,889.937秒（8.03小时），是跨题和跨attempt累加的Agent时间，不是墙钟时间。保存的首个任务开始至最后任务完成约为北京时间2026-10-20 01:13:38至12:03:21（10小时49分44秒）。环境准备、gold和官方判分耗时不在Agent elapsed中。

最新有有效耗时记录的293题，Agent耗时中位数79.29秒、P90为179.20秒；2道启动失败没有Agent result耗时，5道gold未启动。仅1题运行到1200秒超时（sympy-20590），补丁仍通过。提高墙钟时限目前不是最有数据支持的首要改进方向。

## 额外源码资料的使用

日志中观察到下载其他发行版本及查看其源码的行为，需与失败原因分开审计。73题命中了pip download/PyPI相关命令，这只证明尝试，不能证明全部成功；此候选口径也没有覆盖所有raw GitHub下载。一个已通过题django-11019的attempt-0002明确下载并读取后续Django stable/3.0.x版本的widgets.py、test_media.py及topological_sort.py，并与本地源码／测试做diff。events.jsonl的36、62、66、79、88、154行保留相关命令和结果。另见django-15213读取Django4.2源码、sympy-17655跨版本point.py对比。

这些是额外源码资料使用的具体证据。71.33%反映当前工具和联网资料条件下的观测结果；如果目标是测量自行修复能力，应将这种资料访问作为独立实验变量控制和披露。不能仅凭下载行为认定全部答案污染，也不能由此推断SWE-bench官方禁止所有联网。此次没有因此扣分，未推断全部214份正确补丁的来源。具体候选、命令和证据见 `agent_findings.json` 与 [Agent专项核查](agent_notes.md)。

## 建议的处理顺序

| 顺序 | 处理目标 | 本次证据 | 验证方式 |
| --- | --- | --- | --- |
| 1 | thinking-only／输出截断的结束判断与恢复 | 17道空补丁，另3道未过和1道通过也有相同末轮形态 | 先保存原始stop_reason，再对17题做独立对照复测 |
| 2 | API流中断恢复、按根因恢复任务 | 6题受影响，5题实际失分；empty_patch不被retry-errors覆盖 | 固定输入和预算，记录每次恢复与调用用量 |
| 3 | 子模块工作区支持 | 2道Astropy在推理前失败 | 先做不调用模型的启动检查，再补跑 |
| 4 | gold环境与外部服务假设稳定性 | 5题持续P2P失败，另有目标集合外基线噪声 | 先独立验证gold稳定通过，再运行Agent |
| 5 | 减少60轮仍无修改的探索，改进候选补丁后的回归验证 | 20道空补丁，37道补丁未过，其中6道涉及P2P | 追踪首次修改时间和失败测试覆盖，按具体案例改进 |
| 6 | 分离模型尝试、判分重试与流水线恢复 | 2题旧非空补丁判分缺失；24次重试无模型 | 补判旧patch，结果／成本分别保留attempt维度 |

这些是基于当前日志的优先级，不是收益预测。修复评测条件与运行缺陷后，仍需独立复测，不能把未完成样本预先计为成功。

## 数据完整性与复核范围

分析从manifest的300个ID出发，按脚本规则选择latest attempt，检查全部326份state。558份存在的gold／Agent官方report均与state的resolved及tests_status完全一致；引用报告均存在。295条predictions没有重复ID，其补丁逐字与latest patch一致（其中44条为空补丁，非空只有251条）。保存的patch哈希无不一致，events.jsonl无坏JSON行。dataset、Agent源码归档、依赖快照SHA匹配manifest，当前benchmark驱动SHA也匹配。

9题补丁触及测试路径，逐份检查见新增测试、断言或相应import，没有发现删除／放宽原有断言，未因路径命中就标记违规。评测正确性仍受官方目标测试集合覆盖范围限制，resolved不等于在所有场景完全正确。

完整方法、代码行证据和官方4.1.0 parser来源见 [评测脚本审计](harness_notes.md)。未来复现还需固定镜像digest、历史依赖及外部网络条件；现有镜像tag和版本号不等同于所有执行内容的字节级固定。

## 86道未通过题逐题清单

下面的“机制分类”是互斥主分类；同一道题还可能有权限拒绝、截断、回归失败等次要因素。每题的原始日志证据与更细归因在 `instances.json` 的analysis字段、Excel逐题页和专项JSON中保留。置信程度以专项记录为准，不由关键字自动假定。

| 题目 | 机制分类 | Agent状态 | grading F2P失败／P2P失败 | 具体观察与下一步 |
| --- | --- | --- | ---: | --- |
{failed_table}

## 交付物与复现

- `dashboard.html`：无需联网的交互分析，按项目、结果、失败机制搜索／筛选，逐题展开证据。
- `analysis.xlsx`：总览、300题明细、326次历史尝试，可筛选与核对分母。
- `instances.csv`：UTF-8 BOM，可用Windows Excel直接打开。
- `instances.json`、`attempts.json`、`aggregate.json`：归一数据与汇总，原始测试结果保持不变。
- 三份专项核查与对应JSON：保留脚本、环境、Agent侧的证据及判断边界。

在项目根目录运行 `python analysis/swebench_lite_20261020/analyze.py` 可重建归一数据和汇总；再运行 `python analysis/swebench_lite_20261020/build_report.py` 重建本报告与离线交互分析。需要Python 3.11或以上，分析脚本只用标准库，不调用模型或Docker。专项人工归因JSON作为输入保留；Excel另由同目录builder.mjs生成。
"""
    thinking_ids = "、".join(r["instance_id"] for r in rows if r["status"] == "empty_patch" and r["thinking_only_4096_end"])
    repo_table = "\n".join(f"| {v['repo']} | {v['selected']} | {v['resolved']} | {v['statuses'].get('empty_patch',0)} | {v['statuses'].get('unresolved',0)} | {v['statuses'].get('error',0)} | {v['raw_rate']:.2%} |" for v in agg["by_repo"])
    failed_table = "\n".join(f"| {link(r['attempt_path']+'/state.json',r['instance_id'])} | {r['category']} | {r['agent_status'] or '未启动'} | {str(r['f2p_failure'])+'／'+str(r['p2p_failure']) if r['evaluation_status'] in ('resolved','unresolved') else '未判分'} | {cell(reason(r))} {cell(action(r))} |" for r in failed)
    report = report.replace("{thinking_ids}", thinking_ids).replace("{repo_table}", repo_table).replace("{failed_table}", failed_table)
    (OUT / "report.md").write_text(report, encoding="utf-8")
    public = [{k:r[k] for k in ("instance_id", "repo", "title", "status", "category", "agent_status", "attempt_count", "first_status", "lead_turns", "f2p_failure", "p2p_failure", "latest_total_tokens", "cumulative_tokens", "agent_elapsed_seconds", "thinking_only_4096_end", "attempt_path", "failed_tests", "analysis")} for r in rows]
    html_text = r"""<!doctype html>
<html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Aki-Code SWE-bench Lite 分析</title>
<style>
:root{font-family:'Segoe UI','Microsoft YaHei',sans-serif;color:#203047;background:#f4f6fa}body{max-width:1500px;margin:34px auto;padding:0 26px}h1{font-size:28px;margin-bottom:8px}h2{font-size:19px}p{line-height:1.7}.sub{color:#63738b}a{color:#1d56aa}.cards{display:grid;grid-template-columns:repeat(4,1fr);gap:14px;margin:22px 0}.card,.panel{background:white;border:1px solid #dce3ec;border-radius:10px;padding:20px}.value{font-size:30px;font-weight:600;margin-top:8px}.grid{display:grid;grid-template-columns:1fr 1fr;gap:18px}.barrow{display:grid;grid-template-columns:230px 1fr 66px;gap:12px;align-items:center;min-height:32px;font-size:13px}.bar{height:13px;background:#e9edf3;border-radius:3px;overflow:hidden}.fill{height:100%;background:#487bb6}.barrow button{border:0;background:none;text-align:left;color:inherit;font:inherit;cursor:pointer;padding:0}.filters{display:flex;flex-wrap:wrap;gap:12px;margin:20px 0}select,input,button{padding:10px 12px;border:1px solid #ccd6e2;border-radius:5px;background:white;font-size:14px}input{flex:1;min-width:230px}button{cursor:pointer}table{border-collapse:collapse;width:100%;font-size:13px}th{text-align:left;position:sticky;top:0;background:#e8edf5;color:#203047;padding:12px 9px;white-space:nowrap}td{padding:12px 9px;border-bottom:1px solid #e8edf4;vertical-align:top}tr:hover{background:#f5f8fd}.num{text-align:right;font-variant-numeric:tabular-nums}.status{white-space:nowrap;color:#486484}.status.resolved{color:#15705b}.status.empty_patch{color:#946a23}.status.unresolved{color:#a04444}details{max-width:540px}summary{cursor:pointer;line-height:1.6}pre{white-space:pre-wrap;word-break:break-word;background:#f1f4f8;padding:10px;font-size:12px}.scroll{overflow:auto;max-height:800px}.note{padding:14px 18px;border-left:3px solid #728eae;background:#eaf0f7;font-size:14px}.foot{font-size:12px;color:#6a7a90;margin:18px 0}@media(max-width:950px){.grid{grid-template-columns:1fr}.cards{grid-template-columns:1fr 1fr}.barrow{grid-template-columns:210px 1fr 60px}body{padding:0 12px}.scroll{max-height:650px}}
</style>
<h1>Aki-Code SWE-bench Lite 300题分析</h1>
<div class="sub">2026-10-20 · deepseek-flash · harness 4.1.0 · latest attempt · 326次历史尝试</div>
<div class="cards"><div class="card">完整批次通过率<div class="value">71.33%</div>214 / 300</div><div class="card">Gold通过子集<div class="value">72.54%</div>214 / 295</div><div class="card">疑似输出截断且无补丁<div class="value">17题</div>末轮thinking-only，输出4096</div><div class="card">全attempt累计token<div class="value">99.62M</div>包含缓存输入与重试</div></div>
<div class="note">保持214/300原始成绩。Gold、API及接入问题单列，不能自动补成成功；“thinking输出截断”是日志支持的强诊断，未保存原始stop_reason。<a href="report.md">阅读完整报告</a> · <a href="analysis.xlsx">Excel总表</a> · <a href="instances.csv">CSV</a></div>
<div class="grid"><div class="panel"><h2>结果与失败机制</h2><div id="cats"></div><div class="foot">点击类别筛选下方逐题明细。</div></div><div class="panel"><h2>各项目全量通过比例</h2><div id="repos"></div><div class="foot">分母包含该项目所有题；Requests有4题Gold阻断，样本数影响比较。</div></div></div>
<h2>逐题明细</h2><div class="filters"><select id="repo"><option value="">全部项目</option></select><select id="status"><option value="">全部结果</option><option>resolved</option><option>unresolved</option><option>empty_patch</option><option>error</option></select><select id="category"><option value="">全部机制</option></select><input id="query" placeholder="搜索题目ID、问题标题、原因、失败测试"><button id="reset">重置</button><button id="copy">复制筛选ID</button></div>
<p id="stats" class="sub"></p><div class="panel scroll"><table><thead><tr><th>题目／项目</th><th>结果与机制</th><th>具体观察／证据</th><th class="num">F2P／P2P失败</th><th class="num">轮数</th><th class="num">最新token</th><th class="num">尝试</th></tr></thead><tbody id="body"></tbody></table></div>
<div class="foot">所有数字来自本地保存的state、官方报告与Agent事件。筛选统计为当前子集，不能替代完整成绩。此文件无需联网。</div>
<script type="application/json" id="data">__DATA__</script>
<script>
const data=JSON.parse(document.querySelector('#data').textContent),rows=data.rows,agg=data.agg;
const $=id=>document.getElementById(id),esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const reason=r=>r.analysis?.reason||r.analysis?.summary||r.category;
const action=r=>r.analysis?.next_action||r.analysis?.recommendation||r.analysis?.action||'';
for(const v of [...new Set(rows.map(r=>r.repo))].sort())$('repo').add(new Option(v,v));
for(const v of Object.keys(agg.categories))$('category').add(new Option(v,v));
$('cats').innerHTML=Object.entries(agg.categories).sort((a,b)=>b[1]-a[1]).map(([k,n])=>`<div class="barrow"><button data-cat="${esc(k)}">${esc(k)}</button><div class="bar"><div class="fill" style="width:${n/300*100}%;background:${k==='已解决'?'#458c79':'#ad7d56'}"></div></div><span class="num">${n}题</span></div>`).join('');
$('repos').innerHTML=agg.by_repo.map(r=>`<div class="barrow"><button data-repo="${esc(r.repo)}">${esc(r.repo)}</button><div class="bar"><div class="fill" style="width:${r.raw_rate*100}%"></div></div><span class="num">${r.resolved}/${r.selected}</span></div>`).join('');
let filtered=[];
function render(){const q=$('query').value.toLowerCase();filtered=rows.filter(r=>(!$('repo').value||r.repo===$('repo').value)&&(!$('status').value||r.status===$('status').value)&&(!$('category').value||r.category===$('category').value)&&(!q||JSON.stringify([r.instance_id,r.title,reason(r),r.failed_tests]).toLowerCase().includes(q)));const pass=filtered.filter(r=>r.status==='resolved').length,tokens=filtered.reduce((a,r)=>a+r.latest_total_tokens,0);$('stats').textContent=`当前${filtered.length}题，通过${pass}题，子集通过比例${filtered.length?(pass/filtered.length*100).toFixed(2):'0.00'}%，最新attempt token ${(tokens/1e6).toFixed(2)}M`;
$('body').innerHTML=filtered.map(r=>`<tr><td><a href="../../${esc(r.attempt_path)}/state.json">${esc(r.instance_id)}</a><div class="foot">${esc(r.title)}</div></td><td><span class="status ${esc(r.status)}">${esc(r.status)}</span><p>${esc(r.category)}</p><small>Agent: ${esc(r.agent_status||'未启动')}</small></td><td><details><summary>${esc(reason(r))}</summary><p>${esc(action(r))}</p><p>失败测试：</p><pre>${esc(r.failed_tests.join('\n')||'无官方失败项／未判分')}</pre><p>专项归因与证据：</p><pre>${esc(JSON.stringify(r.analysis,null,2))}</pre><a href="../../${esc(r.attempt_path)}/agent/run/events.jsonl">Agent事件</a> · <a href="../../${esc(r.attempt_path)}/patch.diff">补丁</a></details></td><td class="num">${r.f2p_failure??'—'} / ${r.p2p_failure??'—'}</td><td class="num">${r.lead_turns??'—'}</td><td class="num">${r.latest_total_tokens.toLocaleString()}</td><td class="num">${r.attempt_count}</td></tr>`).join('');}
for(const id of ['repo','status','category','query'])$(id).addEventListener('input',render);
$('reset').onclick=()=>{for(const id of ['repo','status','category','query'])$(id).value='';render()};
document.querySelectorAll('[data-cat]').forEach(b=>b.onclick=()=>{$('category').value=b.dataset.cat;render()});document.querySelectorAll('[data-repo]').forEach(b=>b.onclick=()=>{$('repo').value=b.dataset.repo;render()});
$('copy').onclick=async()=>{try{await navigator.clipboard.writeText(filtered.map(r=>r.instance_id).join('\n'));$('copy').textContent='已复制';setTimeout(()=>$('copy').textContent='复制筛选ID',1200)}catch{prompt('复制以下ID',filtered.map(r=>r.instance_id).join('\n'))}};render();
</script></html>"""
    safe_json = json.dumps({"rows": public, "agg": {"categories": dict(categories), "by_repo": agg["by_repo"]}}, ensure_ascii=False).replace("<", "\\u003c")
    (OUT / "dashboard.html").write_text(html_text.replace("__DATA__", safe_json), encoding="utf-8")
    print(json.dumps({"rows":len(rows),"failed_appendix":len(failed),"report_bytes":(OUT/'report.md').stat().st_size,"dashboard_bytes":(OUT/'dashboard.html').stat().st_size},ensure_ascii=False))


if __name__ == "__main__":
    main()
