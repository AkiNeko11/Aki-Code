# 完整分析归档

本包保存2026-10-20对SWE-bench Lite运行lite-baseline-001的分析材料。
ZIP内的analysis/swebench_lite_20261020/包含完整报告、Excel、离线dashboard、
CSV/JSON明细、Agent/gold/评测脚本专项核查、分析及验证脚本、预览与检查记录。

## 查看

将ZIP解压到独立目录，进入analysis/swebench_lite_20261020/：
- report.md：完整报告，逐题清单及统计口径。
- dashboard.html：浏览器打开，离线搜索和筛选。
- analysis.xlsx：整体统计、300题明细、326次尝试。
- agent_notes.md、gold_infra_notes.md、harness_notes.md：专项核查。
- instances.csv、instances.json、attempts.json、aggregate.json：结构化数据。

## 原始数据与重建

本包不包含task_output-wsl原始运行目录，也不包含其本地ZIP。
分析文件保留证据路径和必要摘录；原始数据始终单独本地保存。

如有原始数据，把ZIP内analysis目录和task_output-wsl放在同一项目根目录下。
PowerShell中从该根目录执行（Python 3.11+，分析脚本只使用标准库）：

    python analysis/swebench_lite_20261020/analyze.py
    python analysis/swebench_lite_20261020/build_report.py

仅重建报告时，build_report.py可读取本包已有的归一JSON，不要求原始日志。
Excel的builder.mjs依赖@oai/artifact-tool；依赖目录未打包，需要有该库的环境。
node_modules原为本机运行时的目录联接，已明确排除，避免包含仓库外依赖。

ARCHIVE_MANIFEST.json列出每个文件的字节数和SHA-256。
归档外SHA256SUMS校验公开报告、Excel和ZIP本身。解压会恢复完整材料，
不会修改Agent实现，也不会自动运行评测、联网调用模型或推送Git。
