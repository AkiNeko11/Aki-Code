"""Read-only reconstruction of the archived SWE-bench run; no API or Docker calls.

Run from the repository root with Python 3.11+; writes only beside this script.
Optional reviewer findings are merged by stable instance_id, never into source logs.
"""
from __future__ import annotations

import collections
import csv
import datetime as dt
import hashlib
import json
from pathlib import Path
import re
import statistics

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
RUN = ROOT / "task_output-wsl/lite-baseline-001"


def read(path, default=None):
    return json.loads(path.read_text(encoding="utf-8")) if path.exists() else default


def write(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")


def rel(path):
    return path.relative_to(ROOT).as_posix()


def findings(name):
    value = read(OUT / name, [])
    if isinstance(value, dict):
        for key in ("findings", "instances", "latest_findings", "latest_instances", "latest", "rows"):
            if isinstance(value.get(key), list):
                value = value[key]
                break
        else:
            value = [dict(v, instance_id=k) for k, v in value.items() if isinstance(v, dict)]
    return {v["instance_id"]: v for v in value if isinstance(v, dict) and "instance_id" in v}


def dist(values):
    values = sorted(v for v in values if v is not None)
    if not values:
        return {"n": 0}
    def pct(q):
        i = (len(values) - 1) * q
        lo = int(i)
        hi = min(lo + 1, len(values) - 1)
        return round(values[lo] + (values[hi] - values[lo]) * (i - lo), 3)
    return {"n": len(values), "sum": round(sum(values), 3), "mean": round(statistics.mean(values), 3),
            "median": pct(.5), "p90": pct(.9), "max": max(values)}


def stats_tests(tests, kind, key):
    return len(tests.get(kind, {}).get(key, []))


def parse_attempt(p, dataset):
    state = read(p / "state.json")
    agent = state.get("agent", {})
    saved = read(p / "agent/run/result.json")
    progress = read(p / "agent/run/progress.json", {})
    usage_source = saved if saved is not None else progress
    usage = usage_source.get("usage", {})
    execution = read(p / "execution.json", {})
    patch = read(p / "patch.json", {})
    ev = state.get("evaluation", {})
    tests = ev.get("tests_status", {})
    diff_path = p / "patch.diff"
    diff = diff_path.read_text(encoding="utf-8", errors="replace") if diff_path.exists() else ""
    files = re.findall(r"^diff --git a/(.*?) b/.*$", diff, re.M)
    add = sum(line.startswith('+') and not line.startswith('+++') for line in diff.splitlines())
    delete = sum(line.startswith('-') and not line.startswith('---') for line in diff.splitlines())
    event_types = collections.Counter()
    tool_counts = collections.Counter()
    errors = []
    tool_errors = collections.Counter()
    denial_examples = []
    last_assistant_types = []
    last_thinking_chars = 0
    previous_output_tokens = 0
    last_response_output_tokens = None
    event_path = p / "agent/run/events.jsonl"
    bad_event_lines = 0
    if event_path.exists():
        with event_path.open(encoding="utf-8") as stream:
            for line_no, line in enumerate(stream, 1):
                try:
                    e = json.loads(line)
                except json.JSONDecodeError:
                    bad_event_lines += 1
                    continue
                kind = e.get("type", "unknown")
                event_types[kind] += 1
                if kind == "model_response":
                    current_output = e.get("usage", {}).get("output_tokens", previous_output_tokens)
                    last_response_output_tokens = current_output - previous_output_tokens
                    previous_output_tokens = current_output
                if kind == "message_appended" and e.get("message", {}).get("role") == "assistant":
                    content = e["message"].get("content", [])
                    if isinstance(content, list):
                        last_assistant_types = [b.get("type") for b in content if isinstance(b, dict)]
                        last_thinking_chars = sum(len(b.get("thinking", "")) for b in content if isinstance(b, dict))
                    else:
                        last_assistant_types = ["text"]
                        last_thinking_chars = 0
                if kind == "permission_denied" and len(denial_examples) < 2:
                    denial_examples.append({"line": line_no, "tool": e.get("tool_name"), "excerpt": str({k:v for k,v in e.items() if k not in ("tool_input", "time")})[:500]})
                if kind == "pre_tool_use":
                    tool_counts[e.get("tool_name", "unknown")] += 1
                if kind in ("model_error", "run_error", "error", "model_request_error"):
                    errors.append({"type": kind, "line": line_no, "details": str(e)[:700]})
                if kind == "post_tool_use":
                    result = str(e.get("result", ""))
                    for label, pattern in (("permission_denied", r"permission denied|permission_denied|approval required|not allowed|denied by|outside.*allowed|benchmark.*denied"),
                                           ("command_not_found", r"command not found|No module named"),
                                           ("timeout", r"timed out|timeout"),
                                           ("tool_error_flag", r"\[exit code: [1-9][0-9]*\]")):
                        if re.search(pattern, result, re.I):
                            tool_errors[label] += 1
                            if label == "permission_denied" and len(denial_examples) < 2:
                                denial_examples.append({"line": line_no, "tool": e.get("tool_name"), "excerpt": result[:500]})
    reported_usage = agent.get("usage", {})
    row = {
        "instance_id": state["instance_id"], "repo": dataset["repo"],
        "attempt": p.name, "attempt_path": rel(p), "status": state["status"],
        "phase": state.get("phase"), "started_at": state.get("started_at"),
        "updated_at": state.get("updated_at"), "agent_started_at": agent.get("started_at"),
        "agent_status": agent.get("status"), "agent_reason": agent.get("reason", ""),
        "state_reason": state.get("reason", ""), "execution_reason": execution.get("reason", ""),
        "execution_status": execution.get("status"), "execution_exit_code": execution.get("exit_code"),
        "gold_resolved": state.get("gold", {}).get("resolved"),
        "gold_report": state.get("gold", {}).get("report"),
        "evaluation_resolved": ev.get("resolved"), "evaluation_report": ev.get("report"),
        "evaluation_status": state.get("evaluation_status", "not_run"),
        "patch_status": state.get("patch_status"), "patch_bytes": len(diff_path.read_bytes()) if diff_path.exists() else None,
        "patch_sha_matches": hashlib.sha256(diff_path.read_bytes()).hexdigest() == patch.get("sha256") if diff_path.exists() and patch.get("sha256") else None,
        "patch_files": files, "patch_added_lines": add, "patch_deleted_lines": delete,
        "patch_changes_tests": any(re.search(r"(^|/)(tests?|testing)(/|\.)|(^|/)test_", f) for f in files),
        "f2p_success": stats_tests(tests, "FAIL_TO_PASS", "success") if ev else None,
        "f2p_failure": stats_tests(tests, "FAIL_TO_PASS", "failure") if ev else None,
        "p2p_success": stats_tests(tests, "PASS_TO_PASS", "success") if ev else None,
        "p2p_failure": stats_tests(tests, "PASS_TO_PASS", "failure") if ev else None,
        "failed_tests": tests.get("FAIL_TO_PASS", {}).get("failure", []) + tests.get("PASS_TO_PASS", {}).get("failure", []),
        "lead_turns": agent.get("lead_turns"),
        "latest_request_attempts": usage_source.get("request_attempts", usage.get("calls", 0)),
        "latest_total_tokens": usage.get("total_tokens", 0),
        "input_tokens": usage.get("input_tokens", 0), "output_tokens": usage.get("output_tokens", 0),
        "cache_read_input_tokens": usage.get("cache_read_input_tokens", 0),
        "cache_creation_input_tokens": usage.get("cache_creation_input_tokens", 0),
        "successful_calls": usage.get("calls", 0),
        "agent_elapsed_seconds": agent.get("elapsed_seconds"),
        "summary_accounted_elapsed_seconds": usage_source.get("elapsed_seconds", 0),
        "reported_total_tokens": reported_usage.get("total_tokens"),
        "final_text": agent.get("text", ""),
        "event_counts": dict(event_types), "tool_counts": dict(tool_counts),
        "tool_error_indicators": dict(tool_errors), "denial_examples": denial_examples,
        "error_events": errors, "bad_event_lines": bad_event_lines,
        "model_calls_missing_response": event_types["model_request"] - event_types["model_response"],
        "last_assistant_types": last_assistant_types,
        "last_thinking_chars": last_thinking_chars,
        "last_response_output_tokens": last_response_output_tokens,
        "thinking_only_4096_end": last_assistant_types == ["thinking"] and last_response_output_tokens == 4096,
        "evidence": [rel(p / "state.json")],
    }
    return row


def main():
    manifest = read(RUN / "manifest.json")
    summary = read(RUN / "summary.json")
    source_checks = {}
    for name, key in (("dataset.json", "dataset_sha256"), ("agent-source.tar", "source_sha256"), ("agent-requirements.txt", "requirements_sha256")):
        actual = hashlib.sha256((RUN / name).read_bytes()).hexdigest()
        assert actual == manifest[key], name
        source_checks[name] = actual
    driver_files = sorted((ROOT / "benchmarks/swebench").glob("*.py")) + sorted((ROOT / "benchmarks/swebench").glob("*requirements.txt"))
    current_driver_hash = hashlib.sha256(b"".join(p.name.encode() + b"\0" + p.read_bytes() for p in driver_files)).hexdigest()
    source_checks["current_driver_matches_snapshot"] = current_driver_hash == manifest["driver_sha256"]
    dataset = {v["instance_id"]: v for v in read(RUN / "dataset.json")}
    agent_notes, gold_notes = findings("agent_findings.json"), findings("gold_infra_findings.json")
    attempts, latest = [], []
    for instance_id in manifest["instance_ids"]:
        paths = sorted((RUN / "instances" / instance_id).glob("attempt-*/state.json"))
        assert paths, instance_id
        rows = [parse_attempt(p.parent, dataset[instance_id]) for p in paths]
        attempts.extend(rows)
        row = dict(rows[-1])
        row["attempt_count"] = len(rows)
        row["first_status"] = rows[0]["status"]
        row["model_attempt_count"] = sum(bool(v["agent_status"]) for v in rows)
        row["cumulative_tokens"] = sum(v["latest_total_tokens"] for v in rows)
        row["cumulative_requests"] = sum(v["latest_request_attempts"] for v in rows)
        row["title"] = dataset[instance_id]["problem_statement"].strip().splitlines()[0][:250]
        if row["status"] == "resolved":
            row["category"] = "已解决"
        elif row["gold_resolved"] is False:
            row["category"] = "gold验证失败，Agent未启动"
        elif row["agent_status"] == "error":
            if "incomplete chunked read" in row["agent_reason"]:
                row["category"] = "API流式连接中断"
            else:
                row["category"] = "Runner不支持子模块工作区"
        elif row["status"] == "empty_patch":
            row["category"] = "达到轮数上限且无补丁" if row["agent_status"] == "limit" else "疑似thinking输出截断且无补丁" if row["thinking_only_4096_end"] else "正常结束但无补丁"
        elif row["status"] == "unresolved":
            row["category"] = "补丁同时未修复目标且破坏回归" if row["f2p_failure"] and row["p2p_failure"] else "补丁目标测试未通过" if row["f2p_failure"] else "补丁回归测试未通过"
        else:
            row["category"] = "其他运行错误"
        row["analysis"] = ({**agent_notes.get(instance_id, {}), **gold_notes.get(instance_id, {})} if row["gold_resolved"] is False
                           else agent_notes.get(instance_id) or gold_notes.get(instance_id) or {})
        row["analysis_reason"] = row["analysis"].get("reason", "")
        row["next_action"] = row["analysis"].get("next_action", "")
        row["confidence"] = row["analysis"].get("confidence", "")
        row["evidence_paths"] = "\n".join(str(p) for p in row["analysis"].get("evidence", []))
        latest.append(row)
    counts = collections.Counter(r["status"] for r in latest)
    assert dict(counts) == summary["counts"], (counts, summary["counts"])
    assert sum(r["latest_total_tokens"] for r in attempts) == summary["total_tokens"]
    assert sum(r["latest_request_attempts"] for r in attempts) == summary["request_attempts"]
    # Independently reconcile each actual official JSON report to the state cache.
    report_checks, missing_reports = 0, []
    for row in attempts:
        for kind, key in (("gold", "gold_report"), ("evaluation", "evaluation_report")):
            if not row[key]:
                continue
            p = RUN / row[key]
            if not p.exists():
                missing_reports.append(rel(p))
                continue
            actual = read(p)[row["instance_id"]]
            assert actual["resolved"] == row[f"{kind}_resolved"], p
            state = read(ROOT / row["attempt_path"] / "state.json")
            assert actual.get("tests_status") == state[kind].get("tests_status"), p
            report_checks += 1
    predictions = [json.loads(line) for line in (RUN / "predictions.jsonl").read_text(encoding="utf-8").splitlines() if line.strip()]
    assert len({p["instance_id"] for p in predictions}) == len(predictions)
    for p in predictions:
        row = next(r for r in latest if r["instance_id"] == p["instance_id"])
        assert p["model_patch"] == (ROOT / row["attempt_path"] / "patch.diff").read_text(encoding="utf-8"), p["instance_id"]
    repos = []
    for repo in sorted({r["repo"] for r in latest}):
        rs = [r for r in latest if r["repo"] == repo]
        good_gold = sum(r["gold_resolved"] is True for r in rs)
        resolved = sum(r["status"] == "resolved" for r in rs)
        repos.append({"repo": repo, "selected": len(rs), "gold_validated": good_gold,
                      "resolved": resolved, "raw_rate": resolved / len(rs),
                      "gold_validated_rate": resolved / good_gold if good_gold else None,
                      "statuses": dict(collections.Counter(r["status"] for r in rs)),
                      "tokens": sum(r["cumulative_tokens"] for r in rs)})
    cross = []
    for status in ("completed", "limit", "error", "timeout", None):
        rs = [r for r in latest if r["agent_status"] == status]
        cross.append({"agent_status": status or "not_started", "n": len(rs), "statuses": dict(collections.Counter(r["status"] for r in rs)),
                      "tokens": sum(r["latest_total_tokens"] for r in rs),
                      "elapsed": dist(r["agent_elapsed_seconds"] for r in rs)})
    agg = {
        "run_id": manifest["run_id"], "selected": len(latest), "attempt_count": len(attempts),
        "counts": dict(counts), "categories": dict(collections.Counter(r["category"] for r in latest)),
        "resolved_rate": counts["resolved"] / len(latest),
        "gold_validated": sum(r["gold_resolved"] is True for r in latest),
        "first_attempt_statuses": dict(collections.Counter(r["first_status"] for r in latest)),
        "first_attempt_resolved_rate": sum(r["first_status"] == "resolved" for r in latest) / len(latest),
        "retries": [{k:r[k] for k in ("instance_id", "first_status", "status", "model_attempt_count", "cumulative_tokens")} for r in latest if r["attempt_count"] > 1],
        "agent_status_cross": cross, "by_repo": repos,
        "all_attempt_usage": {"total_tokens": sum(r["latest_total_tokens"] for r in attempts), "request_attempts": sum(r["latest_request_attempts"] for r in attempts),
            **{k:sum(r[k] for r in attempts) for k in ("input_tokens", "output_tokens", "cache_read_input_tokens", "cache_creation_input_tokens", "successful_calls")}},
        "latest_attempt_usage": {"total_tokens": sum(r["latest_total_tokens"] for r in latest), "request_attempts": sum(r["latest_request_attempts"] for r in latest)},
        "thinking_only_4096_ids": [r["instance_id"] for r in latest if r["thinking_only_4096_end"]],
        "permission_denials": {"events": sum(r["event_counts"].get("permission_denied", 0) for r in latest), "affected_instances": sum(bool(r["event_counts"].get("permission_denied")) for r in latest)},
        "agent_latest_seconds": dist(r["agent_elapsed_seconds"] for r in latest),
        "tokens_by_status": {s:dist(r["latest_total_tokens"] for r in latest if r["status"] == s) for s in counts},
        "turns_by_status": {s:dist(r["lead_turns"] for r in latest if r["status"] == s) for s in counts},
        "times_by_status": {s:dist(r["agent_elapsed_seconds"] for r in latest if r["status"] == s) for s in counts},
        "official_tests_latest": {k:sum(r[k] or 0 for r in latest) for k in ("f2p_success", "f2p_failure", "p2p_success", "p2p_failure")},
        "unresolved_patterns": dict(collections.Counter(("F2P+P2P" if r["f2p_failure"] and r["p2p_failure"] else "F2P" if r["f2p_failure"] else "P2P") for r in latest if r["status"] == "unresolved")),
        "patch_modifies_test_ids": [r["instance_id"] for r in latest if r["patch_changes_tests"]],
        "audit": {"official_report_checks": report_checks, "missing_reports": missing_reports,
                  "prediction_count": len(predictions), "summary_counts_match": True,
                  "summary_usage_match": True, "bad_event_lines": sum(r["bad_event_lines"] for r in attempts),
                  "patch_hash_mismatches": [r["attempt_path"] for r in attempts if r["patch_sha_matches"] is False], "source_checks": source_checks},
        "manifest": {k:v for k,v in manifest.items() if k != "instance_ids"},
    }
    write("instances.json", latest)
    write("attempts.json", attempts)
    write("aggregate.json", agg)
    fields = ["instance_id", "repo", "status", "category", "analysis_reason", "next_action", "confidence", "evidence_paths", "agent_status", "agent_reason", "attempt_count", "first_status", "model_attempt_count", "gold_resolved", "patch_status", "patch_bytes", "f2p_success", "f2p_failure", "p2p_success", "p2p_failure", "lead_turns", "latest_request_attempts", "latest_total_tokens", "cumulative_tokens", "agent_elapsed_seconds", "attempt_path"]
    with (OUT / "instances.csv").open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows({k:r.get(k) for k in fields} for r in latest)
    print(json.dumps({k:v for k,v in agg.items() if k not in ("manifest", "retries", "by_repo")}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
