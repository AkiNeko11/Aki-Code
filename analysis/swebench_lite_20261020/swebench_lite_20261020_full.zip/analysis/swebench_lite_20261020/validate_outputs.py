"""Verify the delivered analysis against its archived input and exported workbook."""
import csv
import json
from pathlib import Path
import xml.etree.ElementTree as ET
import zipfile

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
read = lambda name: json.loads((OUT / name).read_text(encoding="utf-8"))
rows, agg = read("instances.json"), read("aggregate.json")
assert len(rows) == len({r["instance_id"] for r in rows}) == 300
assert len(read("attempts.json")) == 326
assert sum(r["status"] == "resolved" for r in rows) == 214
assert sum(agg["categories"].values()) == 300
assert agg["audit"]["official_report_checks"] == 558
assert not agg["audit"]["missing_reports"] and not agg["audit"]["patch_hash_mismatches"]
assert agg["audit"]["source_checks"]["current_driver_matches_snapshot"]
assert len(list(csv.DictReader((OUT / "instances.csv").open(encoding="utf-8-sig", newline="")))) == 300
ns = {"s":"http://schemas.openxmlformats.org/spreadsheetml/2006/main"}


def values(xml):
    result = {}
    for c in xml.findall(".//s:c", ns):
        v = c.find("s:v", ns)
        if v is None or v.text is None:
            result[c.attrib["r"]] = None
        elif c.attrib.get("t") in ("str", "inlineStr"):
            result[c.attrib["r"]] = v.text
        elif c.attrib.get("t") == "e":
            raise AssertionError(f"Excel error {c.attrib['r']} {v.text}")
        else:
            result[c.attrib["r"]] = float(v.text)
    return result


with zipfile.ZipFile(OUT / "analysis.xlsx") as z:
    xmls = [ET.fromstring(z.read(f"xl/worksheets/sheet{i}.xml")) for i in (1,2,3)]
    overview, detail, history = map(values, xmls)
    for addr, expected in {"B6":300,"B7":214,"B8":295,"B13":9247,"B14":99620472}.items():
        assert overview[addr] == expected, (addr, overview[addr])
    assert abs(overview["C7"] - 214/300) < 1e-12
    by_id = {r["instance_id"]:r for r in rows}
    detail_ids = []
    for i in range(6, 306):
        key = detail[f"A{i}"]
        detail_ids.append(key)
        source = by_id[key]
        assert detail[f"C{i}"] == source["status"]
        assert detail[f"D{i}"] == source["category"]
        assert detail[f"P{i}"] == source["latest_total_tokens"]
        assert detail[f"Q{i}"] == source["cumulative_tokens"]
        for col, field in (("L","f2p_success"),("M","f2p_failure"),("N","p2p_success"),("O","p2p_failure")):
            assert detail.get(f"{col}{i}") == source[field], (key, field)
        if key == "django__django-11815":
            assert detail[f"E{i}"] == source["analysis_reason"]
            assert "不能把该明确的序列化差异归因于框架故障" in detail[f"E{i}"]
    assert len(set(detail_ids)) == 300
    assert sum(history[f"M{i}"] for i in range(6, 332)) == 9247
    assert sum(history[f"N{i}"] for i in range(6, 332)) == 99620472
    assert not any(p.startswith("xl/charts/chart") and p.endswith(".xml") for p in z.namelist())

evidence_count = 0
for r in rows:
    for p in r.get("analysis", {}).get("evidence", []):
        assert (ROOT / p).is_file(), p
        evidence_count += 1
    for item in r.get("analysis", {}).get("evidence_details", []):
        assert (ROOT / item["path"]).is_file(), item
dashboard = read("dashboard_validation.json")
assert len(dashboard["checks"]) == 9
result = {"instances":300,"attempts":326,"official_reports_reconciled":558,
          "prediction_patches_reconciled":295,"evidence_paths_present":evidence_count,
          "excel_source_rows_reconciled":300,"excel_history_rows_reconciled":326,
          "excel_unrun_grading_is_blank":True,"excel_cached_metrics_match":True,
          "dashboard_functional_checks":9,"source_snapshot_hashes_match":True,
          "files":{p:(OUT/p).stat().st_size for p in ("report.md","dashboard.html","analysis.xlsx","instances.csv")}}
(OUT / "final_validation.json").write_text(json.dumps(result, ensure_ascii=False, indent=2),encoding="utf-8")
print(json.dumps(result,ensure_ascii=False))
