import fs from 'node:fs';
import vm from 'node:vm';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const dir=path.dirname(fileURLToPath(import.meta.url));
const page=fs.readFileSync(path.join(dir,'dashboard.html'),'utf8');
const raw=page.match(/<script type="application\/json" id="data">([\s\S]*?)<\/script>/)[1];
const data=JSON.parse(raw);
const code=page.match(/<script>\s*([\s\S]*?)<\/script>/)[1];
const elements=new Map();
function element(id){if(!elements.has(id))elements.set(id,{value:'',innerHTML:'',textContent:id==='data'?raw:'',add(){},addEventListener(){}});return elements.get(id)}
const context=vm.createContext({document:{getElementById:element,querySelector:selector=>element(selector.slice(1)),querySelectorAll:()=>[]},Option:function(){},navigator:{},setTimeout(){},prompt(){}});
vm.runInContext(code,context,{timeout:10000});
const evaluate=code=>vm.runInContext(code,context,{timeout:10000});
const checks=[];
function expect(name,query,want){const actual=evaluate(query);if(actual!==want)throw Error(`${name}: ${actual} != ${want}`);checks.push({name,actual});}
expect('Initial unique rows','filtered.length',300);
element('status').value='unresolved';evaluate('render()');expect('Unresolved filter','filtered.length',37);
element('repo').value='sympy/sympy';evaluate('render()');expect('SymPy unresolved intersection','filtered.length',16);
evaluate("$('reset').onclick()");expect('Reset restores full set','filtered.length',300);
element('category').value='疑似thinking输出截断且无补丁';evaluate('render()');expect('Thinking-only empty group','filtered.length',17);
evaluate("$('reset').onclick()");element('query').value='django__django-11815';evaluate('render()');expect('ID query','filtered.length',1);
expect('Corrected cause present',"filtered[0].analysis.reason.includes('不能把该明确的序列化差异归因于框架故障')",true);
evaluate("$('reset').onclick()");element('status').value='error';evaluate('render()');expect('Gold failures filter','filtered.length',5);
expect('Unrun grading displays dash',"$('body').innerHTML.includes('— / —')",true);
if(data.rows.length!==300||new Set(data.rows.map(r=>r.instance_id)).size!==300)throw Error('Missing/duplicate IDs');
if(Object.values(data.agg.categories).reduce((a,b)=>a+b,0)!==300)throw Error('Category total');
fs.writeFileSync(path.join(dir,'dashboard_validation.json'),JSON.stringify({checks,dataRows:300,categoriesTotal:300,validation:'JavaScript execution with a DOM stub; browser visual layout not checked.'},null,2));
console.log(JSON.stringify({passed:checks.length,rows:300}));
