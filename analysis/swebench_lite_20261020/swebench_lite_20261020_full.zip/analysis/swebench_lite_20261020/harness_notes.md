# 评测驱动审计补充

本文件只审查 `benchmarks/swebench`、已保存评测产物及 SWE-bench 4.1.0 官方源码；没有运行模型、Docker 或重新判分。以下路径均相对项目根目录。

## 结果与分母

- `common.py:116–118,127–131,168–175`：每题使用按名称排序的最新 `attempt-*/state.json`，通过数除以 manifest 全部 300 题。当前 **214/300=71.33%** 是“最新 attempt 成绩”；其余为 44 空补丁、37 官方未解决、5 gold 验证失败。
- `runner.py:314–319`：gold 没通过就不启动 Agent。因此 **214/295=72.54%** 可作为“本环境 gold 验证通过子集”诊断指标，但必须与完整 300 题成绩同时展示，不能冒充官方全量成绩。gold 失败也不直接证明原题/gold 补丁有错误，须结合测试日志区分环境、网络服务和测试波动。
- 251 题非空补丁进入 Agent 官方判分，44 条空补丁也保存了 `prediction.json`。所以 `predictions.jsonl` 有 295 条，不意味着官方判了 295 条非空提交；214/251=85.26% 只能称“非空提交的通过比例”。`runner.py:270–288` 与 `common.py:166–167` 可复核。

## 26 次重试对 pass@1 的影响

`runner.py:388–395` 仅让 `--retry-errors` 重跑流水线 `error/interrupted`；`empty_patch/unresolved` 即使来自 API 中断也不会重试。`common.py:144–154` 则累计所有 attempt 的用量，结果与成本口径不同。

- 326 个 attempt 对应 300 题；26 题各有 2 个 attempt。首轮流水线结果是 197 resolved、41 empty_patch、36 unresolved、26 error；**197/300=65.67% 是首次流水线通过率，不能直接等同首次模型解题能力。**
- 26 个首轮 error 中，24 个没有模型请求：有镜像/Docker/GitHub 获取依赖错误及 gold 失败。这类恢复后启动模型属于恢复执行环境，不是额外采样一个模型答案。
- 只有 **django__django-11564** 与 **matplotlib__matplotlib-18869** 各发生两次 Agent 推理。它们第一次都收到了非空补丁，但官方判分因外部依赖网络失败没有 report。前者还有模型流式断连，最新重跑为空；后者最新重跑通过。
- 因此不能把 214/300 无条件称为严格 pass@1，也不宜将 197/300 解释成真实模型 pass@1。若按每题第一次 Agent 启动计算，已有证据确认 213 题通过，2 题旧补丁尚无判分。把这 2 个旧补丁独立判分后才能补齐此口径：目前全量确定通过下界 213/300=71.00%，理论上界 215/300=71.67%；gold 可验证子集相应为 213/295 至 215/295。此区间只处理已知两题旧补丁的判分缺失，不是模型能力的统计置信区间。
- 这两个被替换 attempt 共消耗 **39 次模型请求、400,797 tokens**（228,541 + 172,256）。累计 summary 是 **9,247 requests、99,620,472 tokens**；仅最新 attempt 是 **9,208 requests、99,219,675 tokens**。累计统计正确保留了重试消耗。
- 推荐恢复优先级：已保存并校验的非空补丁发生判分错误时先 `grade`，避免重新生成答案。现有 `grade` 只访问最新 attempt（`runner.py:431–440`），因此上述两题旧 attempt 必须在独立恢复目录中显式选取；不能期待当前 `grade` 自动找回。此审计没有执行恢复或覆盖原目录。

## 官方判分与一个已确认的解析副作用

驱动读取官方 `report.json` 的 `resolved`，不自行从测试进程退出码判题（`runner.py:163–217,331–335`）。每次判分生成新的 UUID/run_id，降低旧缓存误用风险。官方规则要求 tracked FAIL_TO_PASS 与 PASS_TO_PASS 全部成功；未出现在解析映射中的 tracked 测试也被视作失败。因此报告中的 failure 不一定等于一次真实 assertion failure。

已发现 **django__django-14155** 的 1 条解析副作用：

- 最新官方日志：`task_output-wsl/lite-baseline-001/instances/django__django-14155/attempt-0001/grading/37806b2888/logs/run_evaluation/akicode-559f352a5911-37806b2888/akicode/django__django-14155/test_output.txt:39020`。
- 日志把上一项 `test_repr_functools_partial ...` 与 `test_resolver_match_on_request ... ok` 输出在同一行。后者实际打印了 `ok`，官方 Django parser 却把整行前缀当作一个测试名，漏掉后者的正常 key。
- 后者位于此题 **FAIL_TO_PASS**，故该题官方 3 条 F2P failure 中有 1 条属于解析漏记；另外 `test_repr`、`test_repr_functools_partial` 的真实断言仍失败，**整题 unresolved 及类别不变**。不能据此给该题加分，也不能说本次 37 题均为真正的单元测试失败数。
- 对全部 37 个 unresolved 和 5 个 gold error 的失败测试名做了原始日志对应检查；其余所见失败都有真实失败输出。Sphinx 的彩色日志会使未经 ANSI 清洗的字面搜索漏匹配，但已从彩色 FAILED 行确认其 4 题确有失败。此检查不等于证明官方 parser 对所有成功日志不存在任何问题。

官方版本源码证据（本次通过网络读取的主来源；运行时安装包源码并未保留在产物中，不能用 tag 代替本地安装包的字节校验）：

- [v4.1.0 grading.py](https://github.com/SWE-bench/SWE-bench/blob/v4.1.0/swebench/harness/grading.py#L23-L31)：缺失测试名视作失败；`L193–205` 为全部 F2P/P2P 成功才 resolved。
- [v4.1.0 Python parsers](https://github.com/SWE-bench/SWE-bench/blob/v4.1.0/swebench/harness/log_parsers/python.py#L59-L132)：Django 按整行结束的 `... ok` 提取 key；pytest v2 还清洗 ANSI 控制字符。

## API、限额和运行状态统计盲点

- `empty_patch` 是补丁状态，不是根因。`runner.py:280–288` 无论 Agent 正常完成、API 失败或达到限额，只要 runner 得到空 diff 就记 empty_patch；所以仅统计 `counts.error` 会遗漏模型连接错误和 Agent 启动错误。
- Agent `completed`、`limit`、`error`、`timeout` 与官方结果是不同维度。`runner.py:323–335` 即使 infer 报异常，仍允许有效补丁继续判分。当前有达到 limit 或 timeout 仍 resolved 的实例，不能把这些 Agent 停止状态当作未解题。
- 配置是每题 60 主模型轮、80 次请求、100 万 tokens、1200 秒；外层 Docker 执行留 60 秒收尾（`containers.py:239–263`），环境准备和官方测试各 1800 秒（manifest）。`common.py:150–154` 累加 token 与 Agent elapsed，不等于端到端流水线时间或供应商实际费用；无响应请求的计费无法从返回 usage 得知。
- `MAX_TOKENS=4096` 是单次模型输出配置；100 万是每题总 token 预算，两者不可混用。末轮达到 4096 且仅 thinking 的 `completed` 结果，需另列“可能输出截断被误判完成”，但产物没有保留原始 stop_reason 时不能确定为 max_tokens。

## 测试文件修改抽查

逐一读了 9 题被路径筛选标记的最新补丁：django-12589、matplotlib-25442、pytest-7432/9359、sympy-15011/15345/18087/18189/21627。均伴有源码修改，测试侧为新增测试函数、新增断言或所需 import；未发现删除/放宽已有断言或跳过既有测试。`sympy-18189` 在已有测试函数内加断言，`django-12589` 新建测试文件。**不能把“补丁触及 test 路径”本身算作作弊或降低这 9 题分数。**

另见 sympy-15011 残留新增 `wrapper_module_0.pyx`，属于补丁卫生问题，当前官方报告仍通过。只读抽查不能证明补丁在官方覆盖之外完全正确。

## 可复现性核验

当前 `driver_digest()` 与 manifest 的 `56dc83f18db05d700e43b25ba171c88d3fce9e39ec786136ff17b92919c63142` 完全一致；`dataset.json`、`agent-source.tar`、`agent-requirements.txt` 的 SHA-256 也全部匹配 manifest。算法见 `common.py:89–92`；恢复时校验见 `runner.py:126–138`。`host-packages.txt` 记录 `swebench==4.1.0`，manifest 保存数据 revision、源码 commit、模型与预算，可据此定位本次实验。

镜像通过可变 tag 获取，虽每题保存 image ID/digest，重复拉取相同 tag 未必等于原环境。建议保存评测所用 official wheel/源码哈希、原镜像 digest 与必要依赖内容缓存。金标验证和 Agent 判分虽使用新容器，但每个官方评测子进程仍可能从 GitHub 请求历史 requirements；两题旧补丁判分网络失败已经证明“本地有题目镜像”不意味着评分完全离线。

建议分析脚本为每个 attempt 独立保留：pipeline_status、agent_status、patch_status、evaluation_status、root_cause、gold_status、first_agent_attempt、模型请求/响应数、累计/最新 token、原始 stop_reason（未来增加）。统计图表明确区分完整 300、gold 通过 295、已判非空 251 三个集合。
